package com.nnkn.tftoverlay.data

data class Comp(
    val name: String,
    val description: String,
    val units: List<String>
)

plugins {
    id("com.android.application") apply false
    id("org.jetbrains.kotlin.android") apply false
}
